# About expandseq and consdenseseq

`expandseq` and `condenseseq`are two unix/linux command-line utilitiies that
expose the functionality of the python library package `seqLister` to shell users.

